---
name: narrative-image-series
description: This skill should be used when the user needs to generate a series of AI images for content (e.g., Xiaohongshu posts, WeChat articles, course slides) where the images must feel connected, tell a story, and maintain a consistent character/style across all frames. It combines Subject-Context-Style prompting, character consistency anchors, and a 3-act narrative arc.
agent_created: true
---

# Narrative Image Series

## Overview

Turn a disconnected set of AI-generated illustrations into a coherent visual story. This skill forces every image in a series to share the same protagonist, the same world/space, and the same photographic style, arranged along a three-act emotional arc so the audience experiences a progression rather than a slideshow.

Use it whenever the user complains that AI images "have no story," "feel disconnected," or "look like generic stock."

## When to Use

- Xiaohongshu/RED multi-image posts that need scroll-stopping continuity
- WeChat article header/inline image series
- Course or presentation slide decks that need a recurring visual host
- Any content plan where images should reinforce a written narrative arc

## Prerequisites

- The `image-generation` skill (Subject-Context-Style + Character Consistency framework) should be loaded first if available.
- Image generation tool (e.g., ImageGen) must be available.
- A content outline or draft already exists, so the narrative arc can be extracted from it.

## Workflow

### Step 1: Extract the 3-act arc from the content

Map the series to a progression. Common arcs:

| Arc type | Act 1 | Act 2 | Act 3 |
|---|---|---|---|
| Problem → Method → Payoff | Discover the pain / wrong way | Learn/build the method | Get the result / new relationship |
| Before → During → After | Stuck state | Process/transformation | Resolved state |
| Me → Method → Us | Personal struggle | System/tool | Collaboration with AI/others |

For each act, list 1-2 emotions and 1-2 actions the protagonist should perform.

### Step 2: Lock the protagonist and world

Define at least **3 hard visual anchors** for the protagonist and repeat them in every prompt:

- **Character**: age, ethnicity, hairstyle, glasses, clothing item, accessory (ring/watch), expression range
- **Space**: room type, desk, window, plant, wall color, props (mug, notebook, laptop)
- **Style**: film stock, lens, lighting, color grade, depth of field, grain

Example anchors:
> 30-year-old Chinese strategist, short black bob, tortoiseshell round glasses, mustard-yellow knit cardigan, silver thumb ring. Personal studio: wooden desk by a large window, monstera plant, cream walls, ceramic mug. 35mm film, Kodak warm tone, natural window light, f/2.0 shallow depth of field, subtle grain.

### Step 3: Write per-image Subject-Context-Style prompts

For each image, build the prompt with this structure:

```
Subject: [same protagonist] doing [specific action] in [specific emotion]
Context: [same space] + [props that support the narrative beat]
Style: [same style anchors] + [technical constraints: no text, no logos, no watermarks]
```

Every prompt must repeat the character and space anchors verbatim. Do not rely on the model to remember.

### Step 4: Generate and post-process

1. Generate each image individually.
2. Crop/remove any platform "AI-generated" watermark.
3. Resize to target aspect ratio (e.g., Xiaohongshu 3:4 = 1242×1656 px).
4. Overlay any required Chinese text with code (Pillow + system font such as `msyhbd.ttc`); never ask the image model to render Chinese characters.
5. Save with a consistent naming pattern, e.g., `p{post}_{index}_{slug}.png`.

### Step 5: Document the series

Write a `README_配图清单.md` in the output folder containing:
- Character/world/style anchors
- The 3-act arc table
- Per-image file, visual content, and narrative function
- Post-processing checklist
- Replacement recommendations (e.g., swap a placeholder report cover with a real screenshot)

## Quality Checklist

- [ ] Same protagonist appears in every image
- [ ] Same space/lighting/style is recognizable across images
- [ ] Protagonist's expression changes to match the arc
- [ ] No Chinese text rendered by the image model
- [ ] Watermarks removed
- [ ] File sizes and aspect ratios are platform-correct
- [ ] Narrative function of each image is written down

## Anti-patterns

- Do not describe each image as an isolated stock scene.
- Do not change the protagonist's clothing, hairstyle, or environment between images.
- Do not let the image model generate text, QR codes, or UI screenshots.
- Do not skip the narrative arc and rely on "vibe" alone.
